import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;

public class Server {

    public Server() throws Exception{
        ServerSocket serverSocket = new ServerSocket(2024);
        Socket socket = serverSocket.accept();

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedReader tin = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

        System.out.println("Unesi tekst: ");

        String poruka = tin.readLine();

        String hash = hesujMD5(poruka);

        System.out.println(hash);
        out.println(hash);

    }
    public static String bytesToHex(byte[] data) {
        StringBuffer results = new StringBuffer();
        for (byte byt : data)
            results.append(Integer.toString((byt & 0xff) + 0x100, 16).substring(1));
        return results.toString();
    }

    public String hesujMD5(String tekst) throws Exception{

        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        byte[] tekstByte = tekst.getBytes();
        byte[] hashByte = messageDigest.digest(tekstByte);
        String hash = bytesToHex(hashByte);

        return hash;
    }

    public static void main(String[] args) throws Exception{
        new Server();
    }
}
